# Campus Companion iOS - Laboratory Exercise 5

Student: John Einstein Sison

This project adds REST API integration and Codable parsing to the Campus Companion announcements screen.

## Features

- Refresh bar button wired to `refreshTapped(_:)`.
- Named `RemoteEndpoint.announcements` constant.
- URLSession asynchronous GET request with `resume()`.
- Error-first and HTTP status validation.
- Codable `AnnouncementDTO` kept separate from Core Data.
- Main-thread UI updates with `DispatchQueue.main.async`.
- Core Data replacement instead of duplicate insertion.
- “Server Reached” alert showing the received byte count.
- Part 3 fields: location and priority level.

## Reflection

URLSession's completion-handler style is the iOS equivalent of Retrofit's enqueue callback: the request runs asynchronously and returns data, a response, and an error later. Codable and JSONDecoder replace Gson's fromJson step with a type-safe Swift model. DispatchQueue.main.async is required before updating UIKit, just as Android code returns to the main thread before changing views. The decoded DTO is separate from the Core Data entity so a server schema change does not force the persistence model to become the networking model.

## Run

Open `MAD2_Laborator5_Sison.xcodeproj` in Xcode 15 or later, run on an iOS 15+ Simulator with internet access, and open Campus Announcements. Tap Refresh. The list should update from the shared endpoint and show the received byte-count alert.

The `Preview/` folder demonstrates the before-refresh and after-refresh states for environments without Xcode.

import UIKit

final class AnnouncementsViewController: UITableViewController {
    private enum RemoteEndpoint {
        static let announcements = URL(string: "https://raw.githubusercontent.com/feu-mad2/campus-companion-api/main/announcements.json")!
    }

    private var announcements: [CampusAnnouncement] = []
    private let refresh = UIRefreshControl()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "AnnouncementCell")
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .refresh, target: self, action: #selector(refreshTapped(_:)))
        tableView.refreshControl = refresh
        loadAnnouncements()
    }

    @objc func refreshTapped(_ sender: UIBarButtonItem) {
        refresh.beginRefreshing()
        fetchAnnouncementsFromServer()
    }

    private func fetchAnnouncementsFromServer() {
        let task = URLSession.shared.dataTask(with: RemoteEndpoint.announcements) { [weak self] data, response, error in
            if let error { print("Network error: \(error.localizedDescription)"); self?.finishRefresh(); return }
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else { print("Unexpected server response."); self?.finishRefresh(); return }
            guard let data else { self?.finishRefresh(); return }
            do {
                let decodedAnnouncements = try JSONDecoder().decode([AnnouncementDTO].self, from: data)
                print("Decoded \(decodedAnnouncements.count) announcements.")
                DispatchQueue.main.async {
                    self?.replaceAnnouncements(with: decodedAnnouncements)
                    self?.showNetworkConfirmationAlert(byteCount: data.count)
                    self?.finishRefresh()
                }
            } catch { print("Decoding error: \(error)"); self?.finishRefresh() }
        }
        task.resume()
    }

    private func replaceAnnouncements(with dtos: [AnnouncementDTO]) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let request = CampusAnnouncement.fetchRequest()
        let existing = (try? context.fetch(request)) ?? []
        existing.forEach(context.delete)
        dtos.forEach { dto in
            let item = CampusAnnouncement(context: context)
            item.title = dto.title; item.date = dto.date; item.category = dto.category; item.location = dto.location; item.priorityLevel = dto.priorityLevel
        }
        try? context.save(); loadAnnouncements()
    }

    private func showNetworkConfirmationAlert(byteCount: Int) {
        let alert = UIAlertController(title: "Server Reached", message: "Received \(byteCount) bytes from the announcements endpoint.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default)); present(alert, animated: true)
    }

    private func finishRefresh() { DispatchQueue.main.async { self.refresh.endRefreshing() } }
    private func loadAnnouncements() { let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext; let request = CampusAnnouncement.fetchRequest(); request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true)]; announcements = (try? context.fetch(request)) ?? []; if announcements.isEmpty { seedLocalPreview(in: context) }; tableView.reloadData() }
    private func seedLocalPreview(in context: NSManagedObjectContext) {
        [("Midterm Exam Schedule", "2026-08-15", "Academic"), ("Library Extended Hours", "2026-08-20", "General"), ("Council Election Results", "2026-08-10", "Announcement")].forEach { title, date, category in
            let item = CampusAnnouncement(context: context)
            item.title = title; item.date = date; item.category = category; item.location = "Local campus"; item.priorityLevel = "Low"
        }
        try? context.save(); announcements = (try? context.fetch(CampusAnnouncement.fetchRequest())) ?? []
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { announcements.count }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell { let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell", for: indexPath); let item = announcements[indexPath.row]; var content = cell.defaultContentConfiguration(); content.text = item.title; content.secondaryText = "\(item.category ?? "") • \(item.location ?? "") • \(item.priorityLevel ?? "")\n\(item.date ?? "")"; content.secondaryTextProperties.numberOfLines = 2; cell.contentConfiguration = content; return cell }
}

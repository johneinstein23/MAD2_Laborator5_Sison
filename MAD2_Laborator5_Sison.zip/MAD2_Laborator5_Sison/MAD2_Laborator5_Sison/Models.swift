import CoreData

@objc(CampusAnnouncement)
final class CampusAnnouncement: NSManagedObject {
    @NSManaged var title: String?
    @NSManaged var date: String?
    @NSManaged var category: String?
    @NSManaged var location: String?
    @NSManaged var priorityLevel: String?
}

extension CampusAnnouncement { @nonobjc class func fetchRequest() -> NSFetchRequest<CampusAnnouncement> { NSFetchRequest(entityName: "CampusAnnouncement") } }

// A network DTO is intentionally separate from the managed object model.
struct AnnouncementDTO: Codable {
    let title: String
    let date: String
    let category: String
    let location: String
    let priorityLevel: String
}

import UIKit
import CoreData

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MAD2_Laborator5_Sison")
        container.loadPersistentStores { _, error in
            if let error { fatalError("Unresolved Core Data error: \(error)") }
        }
        return container
    }()
    func saveContext() { let context = persistentContainer.viewContext; guard context.hasChanges else { return }; try? context.save() }
}
